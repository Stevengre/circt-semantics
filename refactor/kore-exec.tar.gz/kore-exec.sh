#!/bin/sh
exec kore-exec \
    definition.kore \
    --pattern pgm.kore \
    --output result.kore \
    --module MAIN \
    --strategy all \
    --max-counterexamples 1 \
    --smt-timeout 125 \
    --smt-retry-limit 3 \
    --smt-reset-interval 100 \
    --smt z3 \
    --log-level \
    warning \
    --enable-log-timestamps \
    "$@"
